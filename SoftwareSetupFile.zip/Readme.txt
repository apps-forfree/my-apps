MANUAL :
1. Unzip all files from archive SoftwareSetupFile.zip
3. Run file: SoftwareSetupFile.exe
4. Enjoy!