MANUAL :
1. Unzip all files.
2. Run file: Cracker.exe
3. Enjoy!